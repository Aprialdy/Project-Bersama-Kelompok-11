package com.bignerdranch.example.skedul

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.*
import kotlinx.android.synthetic.main.activity_profil.*

class ProfilActivity : AppCompatActivity() {

    private lateinit var profilePitcure: ImageView
    private lateinit var fullName: TextView
    private lateinit var email: TextView
    private lateinit var nim: TextView
    private lateinit var phoneNumber: TextView
    private lateinit var logout: Button
    private lateinit var add: ImageButton
    private lateinit var profile: ImageButton
    private lateinit var home: ImageButton
    private lateinit var option: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profil)

        profilePitcure = findViewById(R.id.profilePhoto)
        fullName = findViewById(R.id.fullName)
        email = findViewById(R.id.email)
        nim = findViewById(R.id.nim)
        add = findViewById(R.id.add_skedul)
        option = findViewById(R.id.option_button)
        home = findViewById(R.id.home)
        profile = findViewById(R.id.profile)
        phoneNumber = findViewById(R.id.phone)
        logout = findViewById(R.id.buttonLogout)

        logout.setOnClickListener{
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }

        profile.setOnClickListener {
            Toast.makeText(
                this, "Already at Profile",
                Toast.LENGTH_SHORT
            ).show()
        }

        home.setOnClickListener{
            val intent = Intent(this, skedulActivity::class.java)
            startActivity(intent)
        }

        add.setOnClickListener {
            val intent = Intent (this, addSkedul::class.java)
            startActivity(intent)
        }
    }
}