package com.bignerdranch.example.skedul

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class MainActivity : AppCompatActivity() {

    private lateinit var username: EditText
    private lateinit var password: EditText
    private lateinit var loginButton: Button


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        username = findViewById(R.id.editTextTextPersonName)
        password = findViewById(R.id.editTextTextPassword)
        loginButton = findViewById(R.id.button2)

        loginButton.setOnClickListener{

            Toast.makeText(
                this, R.string.succes_login,
                Toast.LENGTH_SHORT
            ).show()

            val intent = Intent(this, skedulActivity::class.java)
            startActivity(intent)

        }

    }
}
