package com.bignerdranch.example.skedul

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView
import android .content.Intent
import android.widget.Button
import android.widget.ImageButton
import android.widget.Toast


class skedulActivity : AppCompatActivity() {

    private lateinit var username: TextView
    private lateinit var skedulList: TextView
    private lateinit var showMore: Button
    private lateinit var add: ImageButton
    private lateinit var profile: ImageButton
    private lateinit var home: ImageButton
    private lateinit var option: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_skedul)

        username = findViewById(R.id.welcome)
        skedulList = findViewById(R.id.appl)
        showMore = findViewById(R.id.button)
        add = findViewById(R.id.add_skedul)
        option = findViewById(R.id.option_button)
        home = findViewById(R.id.home)
        profile = findViewById(R.id.profile)

        showMore.setOnClickListener{
            Toast.makeText(
                this, "You've reached the last list.",
                Toast.LENGTH_SHORT
            ).show()
        }

        profile.setOnClickListener {
            val intent = Intent(this, ProfilActivity::class.java)
            startActivity(intent)
        }

        home.setOnClickListener{
            Toast.makeText(
                this, "Already at Home",
                Toast.LENGTH_SHORT
            ).show()
        }

        add.setOnClickListener {
            val intent = Intent (this, addSkedul::class.java)
            startActivity(intent)
        }

    }


}