package com.bignerdranch.example.skedul

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.ImageButton
import android.widget.Toast

class addSkedul : AppCompatActivity() {

    private lateinit var add: ImageButton
    private lateinit var profile: ImageButton
    private lateinit var home: ImageButton
    private lateinit var option: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_skedul)

        add = findViewById(R.id.add_skedul)
        option = findViewById(R.id.option_button)
        home = findViewById(R.id.home)
        profile = findViewById(R.id.profile)

        profile.setOnClickListener {
            val intent = Intent(this, ProfilActivity::class.java)
            startActivity(intent)
        }

        home.setOnClickListener{
            val intent = Intent (this, skedulActivity::class.java)
            startActivity(intent)
        }

        add.setOnClickListener {
            Toast.makeText(
                this, "Already at Add Shedule",
                Toast.LENGTH_SHORT
            ).show()
        }

    }




}